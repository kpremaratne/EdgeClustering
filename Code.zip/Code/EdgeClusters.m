function [EClusters, ELabels] = EdgeClusters(G, normLf, K)
%
% [EClusters, ELabels] = EdgeClusters(G, normLf, K)
%
% INPUTS: 
% G				= Digraph with N # of vertices and M # of edges; 
% normLf	= (M x M)-sized normalized flow Laplacian matrix; 
% K				= # of edge clusters. 
%
% OUTPUTS: 
% EClusters	= K edge clusters, each given as a digraph object; 
% ELabels		= M-sized vector containing the cluster label of each edge. 
%

N = numnodes(G); M = numedges(G);

%
% GENERATE DATA RECORDS
%
try
    [DR, ~] = eigs(normLf, K, 'smallestabs');
catch
    disp('eigs encounters singular matrix. Trying sigma = 1e-9.');
    sigma = 1e-9;
    [DR, ~] = eigs(normLf, K, sigma); 
end
clear sigma;
disp('normLf-based data records generated.');

%
% K-MEANS CLUSTERING
%
DR = normalize(DR, 2, Norm = 2);
NR = 250;
ELabels = kmeans(DR, K, Replicates = NR); 
disp('Edge labels assigned.');

%
% EDGE CLUSTERS
%
EClusters = cell(1, K); 
G.Edges.ELabels = ELabels;
EClusters_nodes = zeros(K, 1); EClusters_edges = zeros(K, 1);
for i = 1:1:K
    s = G.Edges.EndNodes(G.Edges.ELabels ~= i, 1);
    t = G.Edges.EndNodes(G.Edges.ELabels ~= i, 2);
    G_temp = rmedge(G, s, t);
    IsolatedNodes = (indegree(G_temp) == 0) & (outdegree(G_temp) == 0);
    EClusters{i} = rmnode(G_temp, find(IsolatedNodes));
    EClusters_nodes(i) = numnodes(EClusters{i}); 
    EClusters_edges(i) = numedges(EClusters{i}); 
end 
disp('Edge cluster digraphs generated.')

[~, I] = sort(EClusters_edges, 'desc');
ECluster_Label = (1:1:K)';

array2table([ECluster_Label(I) ...
             int64(EClusters_edges(I)) ...
             int64(EClusters_nodes(I))], ...
            'VariableNames', ...
            {'Cluster Label', '# of Edges', '# of Vertices'})