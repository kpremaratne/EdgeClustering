%
% CODE FOR GENERATING EDGE CLUSTERING PLOTS FOR 
% HUMAN DMN DATASET
%

if ~exist('EClusters', 'var') 
    
%
% PRE-CONDITIONING
%
% This an ungraph (undirected graph). Edge clustering applies to digraphs. 
% So, we convert the ungraph to a digraph by replacing each 
% undirected edge by a pair of directed edges in opposite directions.
%
%   G_u = Given ungraph.
%   G 	= Digraph generated as above from G_u.
%
% MATLAB's incidence(.) does not handle multi- and self-edges.
% So, consolidate multi-edges and remove self-edges:
%
if ~any(strcmp('Weight', G_u.Edges.Properties.VariableNames))
  G_u.Edges.Weight = ones(M, 1);
end  
G_u = simplify(G_u, 'sum'); % G_u is the simplified HumanDMN_Ungraph.
%
if ~any(strcmp('Weight', G.Edges.Properties.VariableNames))
  G.Edges.Weight = ones(M, 1);
end  
G = simplify(G, 'sum'); % G is the simplified HumanDMN_Digraph.
%
% Remove isolated nodes:
IsolatedNodes = find(degree(G_u) == 0); 
G_u = rmnode(G_u, IsolatedNodes);
%
IsolatedNodes = find(indegree(G) == 0 & outdegree(G) == 0); 
G = rmnode(G, IsolatedNodes);
%
clear IsolatedNodes;
%
% There is an isolated triple. We remove this too.
%
G = rmnode(G, find(strcmp(G.Nodes.Group, "C5")));
G_u = rmnode(G_u, find(strcmp(G_u.Nodes.Group, "C5")));
%
% Edge clustering carried out only on the largest component:
%
[Bin, BinSize] = conncomp(G, 'Type', 'weak');
idx = BinSize(Bin) == max(BinSize); % indices of nodes in largest component.
G = subgraph(G, idx);
clear Bin BinSize idx;

%
% PARAMETERS
%
Lstr = 'RGE'; % Edge clustering method.
K = 6;				% # of edge clusters.
%
% If vertex x-y coordinates are not given, get them from MATLAB plot:
%
figure;
if ~any(strcmp(G.Nodes.Properties.VariableNames, 'XCoord'))
    h = plot(G); % Change layout as desired.
    G.Nodes.XCoord = h.XData'; G.Nodes.YCoord = h.YData';
    G_u.Nodes.XCoord = h.XData'; G_u.Nodes.YCoord = h.YData';
end
close(gcf);

%
% EDGE CLUSTERING
% 
% Compute flow Laplacian and its normalized counterpart:
%
[Lf, normLf] = FlowLaplacian(G, Lstr);
%
% Generate edge clusters:
%
[EClusters, ELabels] = EdgeClusters(G, normLf, K);

%
% Convert these edge clusters from digraphs to ungraphs:
%
EClusters_u = cell(1, K);

for i = 1:1:K
		%
		% What digraph edges are in edge cluster i?
		%
		ClusterEdges = (ELabels == i);
		%
		% What edges correspond to these in the ungraph G_u?
		%
    [~, ClusterEdgeIDs_u, ~] ...
        = intersect(G_u.Edges(:, 1), G.Edges(ClusterEdges, 1));
    %
		% What digraph nodes are in edge cluster i?
		%
		ClusterNodeIDs ...
    		= unique([G.Edges.EndNodes(ClusterEdges, 1); ...
                        G.Edges.EndNodes(ClusterEdges, 2)]);
		%
		% What nodes correspond to these in the ungraph G_u?
		%
		ClusterNodeIDs_u ...
    		= unique([G_u.Edges.EndNodes(ClusterEdgeIDs_u, 1); ...
                        G_u.Edges.EndNodes(ClusterEdgeIDs_u, 2)]);
		%
		% What are the ungraph edge clusters corresponding to the 
		% digraph clusters Eclusters?
		% 
		EClusters_u{i} = G_u; 
		temp = setdiff((1:1:numedges(G_u)), ClusterEdgeIDs_u);
		s = G_u.Edges.EndNodes(temp, 1);
    t = G_u.Edges.EndNodes(temp, 2);
		EClusters_u{i} = rmedge(G_u, s, t); 
end
disp('Undirected edge cluster graphs generated.');

end

%
% PLOT EDGE CLUSTERS:
%
Cstring = ['What edge cluster is to be plotted? (enter value in [1:1:', ...
           num2str(K), ']): '];
prompt = Cstring;
ClusterID = input(prompt);  

figure;

%
% Plot the full ungraph:
%
h = plot(G_u, ...
            'LineWidth', 0.5);
h.MarkerSize = 2; 
h.NodeFontSize = 0.1;
h.EdgeColor = [0.7 0.7 0.7];
h.LineStyle = '-';

%
% Highlight specified edge cluster:
%
s = EClusters_u{ClusterID}.Edges.EndNodes(:, 1);
t = EClusters_u{ClusterID}.Edges.EndNodes(:, 2); 
highlight(h, ...
            EClusters_u{ClusterID}, ...
            linewidth = 2, ...
            edgecolor = 'red');