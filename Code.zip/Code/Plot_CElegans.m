%
% CODE FOR GENERATING EDGE CLUSTERING PLOTS FOR 
% CELEGANS DATASET
%

if ~exist('EClusters', 'var') 
    
%
% PRE-CONDITIONING
%
% MATLAB's incidence(.) does not handle multi- and self-edges.
% So, consolidate multi-edges and remove self-edges:
%
if ~any(strcmp('Weight', G.Edges.Properties.VariableNames))
  G.Edges.Weight = ones(M, 1);
end  
G = simplify(G, 'sum');
%
% Edge clustering carried out only on the largest component:
%
[Bin, BinSize] = conncomp(G, 'Type', 'weak');
idx = BinSize(Bin) == max(BinSize); % indices of nodes in largest component.
G = subgraph(G, idx);
clear Bin BinSize idx;

%
% PARAMETERS
%
Lstr = 'DPE'; % Edge clustering method.
K = 15;				% # of edge clusters.
%
% If vertex x-y coordinates are not given, get them from MATLAB plot:
%
figure;
if ~any(strcmp(G.Nodes.Properties.VariableNames, 'XCoord'))
    h = plot(G, layout = 'layered'); % Change layout as desired.
    G.Nodes.XCoord = h.XData'; G.Nodes.YCoord = h.YData';
end
close(gcf);

%
% EDGE CLUSTERING
% 
% Compute flow Laplacian and its normalized counterpart:
%
[Lf, normLf] = FlowLaplacian(G, Lstr);
%
% Generate edge clusters:
%
[EClusters, ELabels] = EdgeClusters(G, normLf, K);

end

%
% PLOT EDGE CLUSTERS:
%
Cstring = ['What edge cluster is to be plotted? (enter value in [1:1:', ...
           num2str(K), ']): '];
prompt = Cstring;
ClusterID = input(prompt); 

figure; 

G_temp = EClusters{ClusterID};
h = plot(G_temp, ...
            layout = 'layered');
h.LineWidth = 2;
h.NodeLabel = G_temp.Nodes.Name;
h.ArrowSize = 8;