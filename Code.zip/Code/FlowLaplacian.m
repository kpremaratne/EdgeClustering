function [Lf, normLf] = FlowLaplacian(G, Lstr)
%
% [Lf, normLf] = Flow_Laplacian(G, Lstr)
%
% INPUTS:
%
% G			= Digraph with N # of vertices and M # of edges. 
%
% Lstr 	= String variable which selects the type of flow Laplacian to be computed:
%   'DPE' = Directed-path-emphasizing flow Laplacian; 
% 	'PRE'	= Producer-receptor emphasizing flow Laplacian; or
% 	'RGE'	= Region-emphasizing flow Laplacian.
%
% OUTPUTS: 
%
%		Lf			= (M x M)-sized flow Laplacian matrix; and 
%		normLf	= (M x M)-sized normalized flow Laplacian matrix. 
%

N = numnodes(G); M = numedges(G);

%
% EDGE VECTOR
%
%	If edges are weighted, select edge weight vector; 
%	otherwise, select edge vector as all '1's.
%
if any(strcmp('Weight', G.Edges.Properties.VariableNames))
    e = G.Edges.Weight;
    disp('Edge vector as specified in G.Edges.Weight.'); 
else
    e = ones(M, 1);
    disp('Edge vector set as all ones.'); 
end

%
% VERTEX VECTOR
%
B = -incidence(G); % Negation reverses MATLAB's edge direction convention.
Babs = abs(B);
sigma = diag(Babs * spdiags(ones(M, 1), 0, M, M) * transpose(Babs));
nu = diag(Babs * spdiags(abs(e), 0, M, M) * transpose(Babs));
nu = nu/norm(e, 1);
clear Babs;

%
% EDGE LAPLACIAN
%
Le = transpose(B) * spdiags(nu, 0, N, N) * B; 
disp('Edge Laplacian computed.');

%
% FLOW LAPLACIAN
%
dualW = Le - diag(diag(Le));
dualD = spdiags(abs(dualW) * ones(M, 1), 0, M, M);
%
% Lstr determines which flow Laplacian is computed:
%
switch Lstr
    case 'DPE'
        Lf = dualD + dualW;
    case 'PRE'
        Lf = dualD - dualW;
    case 'RGE'
        Lf = dualD - abs(dualW); 
end
%
% Force flow Laplacian to be symmetric:
%
Lf = triu(Lf); Lf = Lf + transpose(Lf) - spdiags(diag(Lf), 0, M, M); 
disp('Flow Laplacian computed.');

%
% NORMALIZED FLOW LAPLACIAN
%
% Edge volume vector:
%
Bout = (B > 0); Bin = (B < 0);
Dout = Bout * abs(e); % Vector of sum of absolute values of out-weights.
Din = Bin * abs(e);   % Vector of sum of absolute values of in-weights.

sigma = sigma .* nu;
Fdiag = 0.5 * abs(e) .* (Bout' * (sigma./Dout) + Bin' * (sigma./Din));
clear Bout Bin Dout Din sigma; 

Fdiag = sqrt(Fdiag); 
Fdiag(Fdiag > 0) = 1./Fdiag(Fdiag > 0); 
Fdiag = spdiags(Fdiag, 0, M, M);

%
% Normalized flow Laplacian:
%
normLf = Fdiag * Lf * Fdiag;  
clear Fdiag;
%
% Force normalized flow Laplacian to be symmetric:
%
normLf = triu(normLf); 
normLf = normLf + transpose(normLf) - spdiags(diag(normLf), 0, M, M);
disp('Normalized flow Laplacian computed.');
