%
% CODE FOR GENERATING EDGE CLUSTERING PLOTS FOR 
% PIAZZA-MAZZINNI DATASET
%
% PRE-CONDITIONING
%
% MATLAB's incidence(.) does not handle multi- and self-edges.
% So, consolidate multi-edges and remove self-edges:
%
if ~any(strcmp('Weight', G.Edges.Properties.VariableNames))
  G.Edges.Weight = ones(M, 1);
end  
G = simplify(G, 'sum');
%
% Edge clustering carried out only on the largest component:
%
[Bin, BinSize] = conncomp(G, 'Type', 'weak');
idx = BinSize(Bin) == max(BinSize); % indices of nodes in largest component.
G = subgraph(G, idx);
clear Bin, BinSize, idx;

%
% PARAMETERS
%
Lstr = 'RGE';   % Edge clustering method.
K = 5;          % # of edge clusters.
%
% If vertex x-y coordinates are not given, get them from MATLAB plot:
%
figure;
if ~any(strcmp(G.Nodes.Properties.VariableNames, 'XCoord'))
    h = plot(G, layout = 'force'); % Change layout as desired.
    G.Nodes.XCoord = h.XData'; G.Nodes.YCoord = h.YData';
end
close(gcf);

%
% EDGE CLUSTERING
% 
% Compute flow Laplacian and its normalized counterpart:
%
[Lf, normLf] = FlowLaplacian(G, Lstr);
%
% Generate edge clusters:
%
[EClusters, ELabels] = EdgeClusters(G, normLf, K);

%
% PLOT EDGE CLUSTERS:
%
for i = 1:1:K
    G_temp = EClusters{i}; 
    plot(G_temp, ...
            xdata = G_temp.Nodes.XCoord, ydata = G_temp.Nodes.YCoord, ...
            nodelabel = {}, ...
			linewidth = 2);
    hold on;
end