function PlotEdgeClusters(G, CE)
%
% function PlotEdgeClusters(G, CE)
%
% INPUTS:
% G		= Digraph with M edges; 
% CE	= M-sized vector containing the cluster label of each edge; and
%
% OUTPUT:
% 
% Clusters are plotted on the full digraph G.
%

N = numnodes(G); M = numedges(G); % # of vertices and edges in digraph.
K = max(CE);                      % # of edge clusters.

clear h;

figure;

%
% Plot full digraph G:
%
if any(strcmp(G.Nodes.Properties.VariableNames, 'XCoord'))
    %
    % If node vertex coordinates are given, lay the plot on them:
    %
    h = plot(G, XData = G.Nodes.XCoord, YData = G.Nodes.YCoord);
else
    %
    % otherwise, get the vertex coordinates used by the MATLAB plot:
    %
    h = plot(G);
    G.Nodes.XCoord = h.XData'; G.Nodes.YCoord = h.YData';
end
%
% Remove x-axis and y-axis ticks:
%
set(gca, 'xtick', []); set(gca, 'ytick', []);

if any(strcmp(G.Nodes.Properties.VariableNames, 'Name'))
    h.NodeLabel = G.Nodes.Name; 
end
h.MarkerSize = 5; 
%
% De-emphasize full digraph:
%
h.NodeFontSize = 0.1;
%h.NodeLabelColor = [1 1 1];
h.EdgeColor = [0.95 0.95 0.95];
h.LineStyle = ':';

%
% Choose a colormap that has K different colors: 
% 
cmap = hsv(K); % hsv is the colormap used here.

ClusterID = 2;
%
% IDs of edges in cluster:
%
ClusterEdgeID = find(CE == ClusterID); 
%
% IDs of vertices in cluster:
%
ClusterNodes ...
		= unique([G.Edges.EndNodes(ClusterEdgeID, 1); ...
		          G.Edges.EndNodes(ClusterEdgeID, 2)]);
ClusterNodeID = findnode(G, ClusterNodes);
    
highlight(h, ... 
		'Edges', ClusterEdgeID, ...
    'MarkerSize', 5, ... 
    'NodeFontSize', 0.1, ...
    'NodeLabelColor', [0 0 0], ...
    'LineWidth', 2, ...  % Use 2 or 4
    'EdgeColor', cmap(ClusterID, :), ...
    'LineStyle', '-', ...
    'ArrowSize', 7); 
h.EdgeAlpha = 1.0;

clear ClusterEdgeLineWidth DEN
