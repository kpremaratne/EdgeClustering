function EClusters = EdgeClusterDigraphs(G, ELabels)
%
% EClusters = EdgeClusterDigraphs(G, EdgeLabels)
%
% INPUTS: 
%
% G       = Digraph with N # of vertices and M # of edges; and 
% ELabels	= M-sized vector containing the cluster label of each edge.
%
% OUTPUT: 
%
% EClusters	= The K edge clusters, each given as a digraph object. 
%

N = numnodes(G); M = numedges(G); 
K = max(ELabels);

%
% EDGE CLUSTERS
%
EClusters = cell(1, K); 
G.Edges.ELabels = ELabels;
for i = 1:1:K
    s = G.Edges.EndNodes(G.Edges.ELabels ~= i, 1);
    t = G.Edges.EndNodes(G.Edges.ELabels ~= i, 2);
    G_temp = rmedge(G, s, t);
    G_temp.Edges.ELabels = [];
    IsolatedNodes = (indegree(G_temp) == 0) & (outdegree(G_temp) == 0);
    EClusters{i} = rmnode(G_temp, find(IsolatedNodes));
end 
disp('Edge clusters generated as digraphs.')