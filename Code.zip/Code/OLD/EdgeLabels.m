function ELabels = EdgeLabels(normLf, K)
%
% ELabels = EdgeLabels(normLf, K)
%
% INPUTS: Given a digraph G with M edges, 
%
% normLf	= (M x M)-sized normalized flow Laplacian matrix; 
% K				= # of edge clusters. 
%
% OUTPUTS: 
%
% ELabels	= M-sized vector containing the cluster label of each edge. 
%

M = size(normLf, 1);

%
% GENERATE DATA RECORDS
%
try
    [DR, ~] = eigs(normLf, K, 'smallestabs');
catch
    disp('eigs encounters singular matrix. Trying sigma = 1e-9.');
    sigma = 1e-9;
    [DR, ~] = eigs(normLf, K, sigma); 
end
clear sigma;
disp('normLf-based data records generated.');

%
% K-MEANS CLUSTERING
%
ELabels = zeros(M, 1); 

DR = normalize(DR, 2, Norm = 2);
NR = 250;
ELabels = kmeans(DR, K, Replicates = NR); 
disp('Edge labels assigned.');



ClusterSize = ELabels(1:Nmax, NVal == Nmax);
[ClusterSize, ClassLabel] = sort(ClusterSize, 'desc');
array2table([(1:1:Nmax)' ClassLabel ClusterSize], ...
            'VariableNames', ...
            {'Cluster #', 'Label', 'Size'})



